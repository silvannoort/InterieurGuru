import java.util.List;

public class Artikel {
    private String artikelID;
    private String artikelnaam;
    private String inhoud;
    private List<String> afbeeldingen;
    private String categorie;

    

    public void voegArtikelToe() {
        
    }

    public void updateArtikelInfo() {
        
    }

    public void verwijderArtikel() {
       
    }
}
