public class Beheerder {
    private String beheerderID;
    private String beheerdersnaam;
    private String wachtwoord;
    private String email;

    

    public void beheerGebruikers() {
        
    }

    public void monitorSysteem() {
        
    }
}