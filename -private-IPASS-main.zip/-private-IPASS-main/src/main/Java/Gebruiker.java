public class Gebruiker {
    private String gebruikersID;
    private String gebruikersnaam;
    private String wachtwoord;
    private String email;


    public void doorzoektWebsite(String categorie) {
        
    }

    public void bekijktArtikelen() {
        
    }

    public void kliktProductlink() {
        
    }
}