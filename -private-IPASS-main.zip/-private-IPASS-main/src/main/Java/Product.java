public class Product {
    private String productID;
    private String productnaam;
    private String categorie;
    private String affiliateLink;
    private String partnerwebsite;

    

    public void voegProductToe() {
       
    }

    public void updateProductInfo() {
        
    }

    public void verwijderProduct() {
        
    }
}
