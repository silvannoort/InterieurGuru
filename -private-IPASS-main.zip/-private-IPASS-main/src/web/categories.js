function redirectToCategory(categoryPage) {
    window.location.href = categoryPage;
}
AOS.init({
    duration: 1000, 
    delay: 100, 
    once: true, 
  });
  